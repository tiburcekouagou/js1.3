/**
 * Déclarer une variable « colors » contenant les valeurs "Rouge" et "Bleu".
 * Afficher "Bleu" dans la console. En utilisant le tableau, hein !
 */
