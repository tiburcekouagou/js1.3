/**
 * Déclarer une variable « colors » contenant un tableau vide.
 * Puis un second temps, ajouter "Rouge" et "Bleu" à ce tableau.
 * Enfin, afficher "Rouge" sur la page web, toujours en utilisant le tableau.
 */
